#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODING

#include <iostream>
#include "legacyapps/flooding/flooding_init.h"
#include "legacyapps/flooding/flooding_processor_factory.h"
#include "sys/simulation/simulation_controller.h"
#include "sys/simulation/simulation_task_keeper.h"
#include "sys/transm_models/transmission_model_keeper.h"
#include "apps/reading/readings/reading_keeper.h"


extern "C" void init_flooding( shawn::SimulationController& sc )
{
   USER( "Initialising Flooding Processor (Flooding)" );
   flooding::FloodingProcessorFactory::register_factory( sc );
}

#endif
