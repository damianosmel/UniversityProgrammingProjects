#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODSET

#include "legacyapps/floodset/floodset_processor.h"
#include "legacyapps/floodset/floodset_message.h"
#include "sys/simulation/simulation_controller.h"
#include "sys/node.h"
#include "sys/taggings/basic_tags.h"
#include <iostream>
#include <limits>
#include <cmath>
#include <algorithm>
using namespace std;

namespace floodset {

    FloodSet::
    FloodSet()
    {

    }
    // ----------------------------------------------------------------------

    FloodSet::
    ~FloodSet() {
	//delete[] arrayOfValues_;
    }
    // ----------------------------------------------------------------------

    void
    FloodSet::
    special_boot(void)
    throw () {
    }
    // ----------------------------------------------------------------------

    void
    FloodSet::
    boot(void)
    throw () {

        //initialize the algorithm variables
	decision_at_round_ = -1;//at start each processor doesn't decide
	const shawn::SimulationEnvironment& se = owner().world().simulation_controller().environment();// read input parameteres of .conf file
       	am_ = se.required_int_param("AM");// initialize am variable
        processors_num_ = se.required_int_param("PROCESSORS_NUM");// initialize processors_num variable
	fail_prop_ = ( se.required_int_param("FAIL_PROP") ) * 0.1;//get the value of fail propability
	//fail_prop_ = fail_prop_ * 0.1;
	hyper_bound_ = ( se.required_int_param("HYPER_BOUND") ) * 0.00000001;//get the hyper bound for the corresponding number of nodes
	//cout<<"to processors num einai "<<processors_num_<<endl;
        //read the input value of the node from the topology file
	shawn::TagHandle tag = owner_w().find_tag_w("input_value");
        if ( tag.is_not_null() )
        {
                input_tag_ = dynamic_cast<shawn::IntegerTag*>( tag.get() );
        }//close if
	input_value_ = input_tag_ ->value();
	//input_value_ = static_cast<int>(input_value_)%am_;//get the input_value % AM
	input_value_ = input_value_%am_;
      	// Initialize the array with default value, which supposed to be -1
	arrayOfValues_ = new  int[processors_num_];
	for(int i=0; i < processors_num_; i++)//initialize values of each array to -1
	{
		arrayOfValues_[i] = -1;
	}
      	// In the beginning each processor knows only its value
	arrayOfValues_[id()] = input_value_;
	cout << "Hello from node " << id() << " my input value = " << input_value_ << endl;
	/*for( int i=0;i < processors_num_; i++)
        {
                cout << arrayOfValues_[i] << endl;
        }*/
    }
    // ----------------------------------------------------------------------

    bool
    FloodSet::
    process_message(const shawn::ConstMessageHandle& mh)
    throw () {
	//cout<<"in start of process"<<endl;
        const floodsetMessage* floodsetmsg = dynamic_cast<const floodsetMessage*> ( mh.get() );
	//cout<<"in process message"<<endl;
        if ( floodsetmsg != NULL && owner_w() != floodsetmsg->source() )
	{
            handle_flooding_message_node( *floodsetmsg );
            //handle_floodset_message( *floodsetmsg );
	    //cout<<"returns true!!!"<<endl;
	    return true;
        }

        return shawn::Processor::process_message( mh );
    }
    // ----------------------------------------------------------------------

    void
    FloodSet::
    work(void)
    throw () {

	count_unknown_ = 0; // initialize the number of unknown input values of other processors
	//define a array to store 5 pairs of (vote,count_vote), as x mod 5 has 5 possible results
	int count_vote [5] = { 0, 0, 0, 0, 0 };
	float prop_of_drop_send;
	float fl_sim_round = (float)( simulation_round() - 1 );
	//int *count_vote;
	//count_vote = new int[5];
	//at each round send a message with the array of node values
	cout << "SEND_MSG: Now I am sending my list to my neighbors!" << endl;
        send( new floodsetMessage(arrayOfValues_,processors_num_) );

	//int count_vote [5] = { 0, 0, 0, 0, 0 };
	cout << "I am processor with id = " << id() << " my list is: " << endl;//print my list of values
	cout << "{ ";
	for(int i=0; i < processors_num_; i++)
	{
		if( i != 0 && i%10  == 0 )
		{
			cout << endl << "(Id: " << i << ", Vote: " << arrayOfValues_[i] << "), ";
			//cout<<i<<": "<< arrayOfValues_[i]<<", ";
		}
		else
		{
			cout << "(Id: " << i << ", Vote: " << arrayOfValues_[i] << "), ";
		}
		if (arrayOfValues_[i] == -1)
		{
			count_unknown_++;
		}
	}//close for

	cout << "}" <<endl;
	// At the right number of round:
        // Apply the consensus critiria to select a number and
        // Then set the processor state to Inactive
	if ( simulation_round() != 0 )
	{
		prop_of_drop_send = pow(fail_prop_,fl_sim_round)*(1.0-fail_prop_); // find the propability of (#rounds-1) contiguous dropped messages and 1 successive message
		// if previous propability is lower than the given bound proccessor decides and then becomes inactive, 
		//( equality betwwen two floats is impossible with good propability )
		//if( hyper_bound_ - prop_of_drop_send <= 0.00000001 )
		if( prop_of_drop_send < hyper_bound_ )
		{
			//if you don't know input values of other processors, continue sending you array to your neighbors
                	cout << "BEFORE DECISION: I don't know " << count_unknown_ << " value(s)!" << endl; // before decision made inform how many unknown values you have
			//if you know input values of all other processors, you should decide the max frequent vote of in case of tie decide the minimum value of maximum voted options
                	max_freq_= 0; // initialize maximum frequency among all votes
                	max_freq_vote_ = 0; // initialize maximum frequent vote to 0
                	tie_flag_ = 0;
                	if ( decision_at_round_ == -1 )//if processor hadn't decided, update decision round to current round
                	{
                        	decision_at_round_ = simulation_round();
                	}
                	for (int i=0; i < processors_num_; i++)//pass through all the arrray of votes to count the votes
                	{
                        	count_vote[arrayOfValues_[i]]++;
                	} // close for
                	cout << "I am processor with id = " << id() << " my vote array is:" << endl << "{ ";
                	for(int i=0;i<5;i++)
                	{
                        	cout << "(Vote: " << i << ", Vote_Counter: " << count_vote[i]<< "), "; // print each pair of count vote array
                        	if( max_freq_ == count_vote[i] ) // check if the maximum frequent vote is equal to current count
                        	{
                                	tie_flag_ = 1;
                        	}
                        	else if( max_freq_ < count_vote[i]) //if maximum frequency is lower than current vote counter update maximum frequency and maximum frequent vote
                        	{
                                	max_freq_ = count_vote[i];
                                	max_freq_vote_ = i;
                                	tie_flag_ = 0; // change the tie_flag to false, as the maximum frequent vote changed
                        	}
                	}//close for
			cout <<"}"<< endl;//print a new line for better appearance
                	if( tie_flag_ == 1) // check if there was tie in the maximum frequent vote
                	{
                        	for(int i=0;i<5;i++)//as there was a tie between maximum voted options find the minimum value of those options
                        	{
                                	if ( count_vote[i] == max_freq_ )//find the first maximum voted option, then terminate for-loop
                                	{
                                        	decision_ = i;
                                        	break;
                                	}//close inner if
                        	}//close inner for
                        	cout << "DECISION: TIE TRUE " << "In " << decision_at_round_ << " rounds, I am processor with id = " << id() << " and i decide the minimum vote = " << decision_ << endl;
                	}
                	else
                	{
                        	decision_ = max_freq_vote_;
                        	cout << "DECISION: TIE FALSE " << "In " << decision_at_round_ << " rounds, I am processor with id = " << id() << " and i decide the maximum frequent vote = " << decision_ << endl;
                	}//close inner if-else
                	set_state(Inactive);//as each processor decided, deactivate it
		}//close inner if prop_drop_send
	}//close external if simulation_round()
    }
    // ----------------------------------------------------------------------

    void
    FloodSet::
    handle_flooding_message_node(const floodsetMessage& floodsetmsg)
    {
	//for each processor that receives a message print the sender's id
	//cout << "GET_MSG: Processor with id = " << id() << ", I got list of " << floodsetmsg.source_w().id() << endl;

	int *temp_array = floodsetmsg.values(); //save the received list to a temporary array

	for (int i=0; i < processors_num_; i++)//update values from received lists
        {
		//cout<<"received list's element "<<temp_array[i]<<endl;
		if( temp_array[i] != -1 )//check if ith element of received list is a input value and current processor dosn't know that value
		{ //cout<<temp_array[i]<<endl;
        		arrayOfValues_[i] = temp_array[i];
		}//close if
	}//close for
	//delete [] temp_array;//delete temporary array
    }
    // ----------------------------------------------------------------------

}
#endif
