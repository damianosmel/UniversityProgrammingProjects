#ifndef __SHAWN_LEGACYAPPS_FLOODING_FLOODING_INIT_H__
#define __SHAWN_LEGACYAPPS_FLOODING_FLOODING_INIT_H__
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODING

namespace shawn
{ 
	class SimulationController; 
}

/** This method is invoked by Shawn to initialize the current module
  */
extern "C" void init_flooding( shawn::SimulationController& );


#endif
#endif