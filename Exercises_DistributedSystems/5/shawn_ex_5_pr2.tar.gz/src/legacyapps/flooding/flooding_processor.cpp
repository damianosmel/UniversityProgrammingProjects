/************************************************************************
 ** This file is part of the network simulator Shawn.                  **
 ** Copyright (C) 2004-2007 by the SwarmNet (www.swarmnet.de) project  **
 ** Shawn is free software; you can redistribute it and/or modify it   **
 ** under the terms of the BSD License. Refer to the shawn-licence.txt **
 ** file in the root of the Shawn source tree for further details.     **
 ************************************************************************/
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODING

#include "legacyapps/flooding/flooding_processor.h"
#include "legacyapps/flooding/flooding_message.h"
#include "sys/simulation/simulation_controller.h"
#include "sys/taggings/basic_tags.h"
#include "sys/node.h"
#include <iostream>
#include <limits>
#include <cmath>
#include <ctime>
#include <cstdlib>
using namespace std;

namespace flooding
{

   // ----------------------------------------------------------------------
   FloodingProcessor::
   FloodingProcessor()
   {
	//initialize hops counter, parent random integer, sum and send_msg variable  of each processor
	hops_ = 20000;
	parent_ = -1;
	send_msg = false;
   }
   // ----------------------------------------------------------------------
   FloodingProcessor::
   ~FloodingProcessor()
   {}
   // ----------------------------------------------------------------------
   void
   FloodingProcessor::
   special_boot( void )
      throw()
   {
   }
   // ----------------------------------------------------------------------

   // Kaleite mia fora prin apo ton  ton prwto gyro(iteration 0)
   void
   FloodingProcessor::
   boot( void )
      throw()
   {
	const shawn::SimulationEnvironment& se = owner().world().simulation_controller().environment();// read input parameteres of .conf file
	graph_diameter_ = se.required_int_param("graph_diameter");
        am_ = se.required_int_param("AM");
	processors_num_ = se.required_int_param("PROCESSORS_NUM");
	//read the input value of the node from the topology file
        shawn::TagHandle tag = owner_w().find_tag_w("input_value");
        if ( tag.is_not_null() )
        {
                input_tag_ = dynamic_cast<shawn::IntegerTag*>( tag.get() );
        }//close if
        input_value_ = input_tag_ ->value();
	//srand( (unsigned)(time(0) + id()) );
	//input_value_ = (rand() % 40) + 1;
	//assume that flooding begins from processor with id = 0.
        if( id() == 0 )
        {
                //initialize the array with default value, which supposed to be -1
		array_of_values_ = new int[processors_num_];
		for (int i=0; i < processors_num_; i++)//initialize values of each array to -1
		{
			array_of_values_[i] = -1;
		}//close for
		array_of_values_[id()] = input_value_;//set the input value of root into the array of input values
		//update the hops counter for root
                hops_ = 0;
                //parent_ = ;
                send( new FloodingMessage( hops_,0,id() ) );
                cout << "I am processor with id = "<< id() <<" (root) my parent's id = "<< parent_<<"."<<endl;
		cout <<"BFS_TREE: In " << hops_ << " hops, processor with id = " << id() << " is sending the flooding message!" <<endl;
        }//close if
   }
   // ----------------------------------------------------------------------

   // Kaleite kathe fora poy h diergasia lambanei ena mhnyma
   // To orhsma einai mia class poy periexei to mhnyma
   bool
   FloodingProcessor::
   process_message( const shawn::ConstMessageHandle& mh )
      throw()
   {
       // mh.get(): epistrefei to mhnyma
       // dynamic_cast<const FloodingMessage*> : to metatrepoyme sthn class poy
      const FloodingMessage* floodmsg = dynamic_cast<const FloodingMessage*> ( mh.get() );

      if ( floodmsg != NULL && id() != floodmsg->source().id() )
      {
          //kaloume mia method gia na xeirhstoume to mhnyma typou flooding
         handle_flooding_message( *floodmsg );
         return true;
      }

      return shawn::Processor::process_message( mh );
   }
   // ----------------------------------------------------------------------
   //Ekteleite se kathe gyro(iteration) ths exomoiwshs
   void
   FloodingProcessor::
   work( void )
      throw()
   {
     	if ( simulation_round() > graph_diameter_ )//if simulation rounds are greater than graph diameter tree has been constructed so each processor convergecast its input value
	{
		if( id() != 0 ) // if processor isn't root check to see if it will start convergecasting their input values
		{
			if( send_msg == false ) // if processor has not send message to her parent, she will send now!
			{
				send( new FloodingMessage( input_value_,parent_,id() ) ); //processor sends her input value to her parent
				cout << "CONVERGECAST: My id = "<< id() <<", sending my input value to my papa with id = " << parent_ << endl;
				send_msg = true;
			}//close 1 inner if
		}//close 2 inner if
	}//close external if
	if ( simulation_round() == ( 2 * graph_diameter_ + 1 ) && id() == 0 )
        {
		// declare 3 boolean variables for each propositions and one extra flag for each examination of third proposition
                bool propos1_ = false; // assume that no insert value such that value mod (AM) = 9
                bool propos2_ = true; // assume that all insert values are even numbers
                bool propos3_ = true; // at start assume that proposition 3 holds for all even insert values
                bool flag_3_q_v_;
		// when all convergecast messages arrived at root, root announces inputs value of each processor
                cout << "In "<< simulation_round() <<" rounds, I am processor with id = " << id() << " (root) the table with each processor input value is: " << endl;
		for ( int i=0; i < processors_num_; i++ )
                {
			cout << i << " -> "<< array_of_values_[i] << endl;
                }// close for
                // pass through all values to check if first and second proposition hold
                for ( int i=0; i < processors_num_; i++ )
                {
			if ( array_of_values_[i] % am_ == 9 )// check if there is a insert value of any processor that value_processor % AM = 9
                     	{
				propos1_ = true;
                        }// close if
                        if ( array_of_values_[i] % 2 == 1 )// check if there is a odd insert value
                        {
                               	propos2_ = false;
                        }// close if
                      	// if you find that there is a insert value for which first proposition holds and another( or the same ) insert value for which second
                        // proposition doesn't, terminate loop
                        if ( propos1_ == true && propos2_ == false )
                        {
				break;
                        }// close if
		}// close for
                // to check the third proposition for each even insert value i_q examine if there is a different insert value i_v so that i_q + i_v > 10
                for( int i = 0; i < processors_num_; i++ )
                {
			if ( array_of_values_[i] % 2 == 0)
                        {
				flag_3_q_v_ = false; // at start flag is false for each even insert number that will be examined
                                for( int j = 0; j < processors_num_; j++ )
                                {
					if ( (i != j) && (array_of_values_[i] + array_of_values_[j] > 10) )
                                        {
						flag_3_q_v_ = true;
                                                break;//as you find i_v so that i_q + i_v > 10 and i_q is even terminate the examination for that i_q
                                        }// close if
                                }// close inner for
                                // if flag is false after examination then there is no i_v : i_q + i_v > 10 and i_q even number,
                                // so third proposition doesn't hold => terminate the external for
                                if( flag_3_q_v_ == false )
                                {
					propos3_ = false;
                                }// close inner if
			} //close if
		}// close for
                // after examination processor with id = 0 accounces the results
                cout <<"RESULT 1: My id = "<< id() << "(root)"<< ", proposition 1 << Exists q so that i_q % AM = 9 >> is "<< propos1_<< endl;
                cout <<"RESULT 2: My id = "<< id() << "(root)"<< ",proposition 2 << It doesn't exist q so that i_q % 2 = 1 >> is "<< propos2_<< endl;
               	cout <<"RESULT 3: My id = "<< id() << "(root)"<< ", proposition 3 << For each even i_q, exists i_v so that i_q + i_v > 10 >> is "<< propos3_<< endl;
	}//close external if
   }
   // ----------------------------------------------------------------------
   void
   FloodingProcessor::
   handle_flooding_message( const FloodingMessage& flooding )
      throw()
   {
	//each processor prints the source of received message.
	cout <<"Processor with id = "<< id() << " received flooding msg from " << flooding.source_w().id() << endl;

	if ( simulation_round() <=  graph_diameter_ )//check whether this round is for tree construction or convergecast messages
	{
		//Handle tree construction message
		if ( hops_ > flooding.hops() + 1 )//check if stored hops is greater than send message's hops,if so update node's hops counter and parent, otherwise ignore it
		{
			//increase by one hops counter
			hops_ = flooding.hops() + 1;
			parent_ = flooding.parent();
			cout <<"I am processor with id = "<< id() <<" my parent's id = "<< parent_<<"."<<endl;
			//as processor's parent was changed, processor send message
			send( new FloodingMessage( hops_,id(),-19 ) );
                        cout <<"BFS_TREE: In "<< hops_ << " hops, processor with id = "<< id() <<" is sending the flooding message!"<<endl;
		}//close inner if
	}//close external if
	else//as now the tree has been constructed, processors convergecast the incoming messages to the root (processor with id = 0)
	{
		//Handle convergecast message
		if ( id() != 0 )//check if processor  is internal node or root
		{
			if ( id() == flooding.parent() )//check if this processor is papa of sender
			{
				//if processor is the sender's papa send a new message to papa of this processor maintaining the id of message initial sender
				send( new FloodingMessage( flooding.hops(),parent_,flooding.id() ) );
				cout <<"CONVERGECAST: My id = "<< id() <<", i received message from my children, sending to my papa with id=" << parent_<<" !"<<endl;
			}//close 1 inner if
		}//close 2 inner if
		else
		{
			//cout << "hello in "<< simulation_round()<< " 2 * diam = "<< 2*graph_diameter_<< endl;
			//as convergecast message reachs the root, root update its' array of values
			array_of_values_[ flooding.id() ] = flooding.hops();
			/*// if maximum rounds for construction and convergecast of messages have passed, root can evaluate the three propositions
			if ( simulation_round() == ( 2 * graph_diameter_ ) )
			{
				// declare 3 boolean variables for each propositions and one extra flag for each examination of third proposition
				bool propos1_ = false; // assume that no insert value such that value mod (AM) = 9
				bool propos2_ = true; // assume that all insert values are even numbers
				bool propos3_ = true; // at start assume that proposition 3 holds for all even insert values
				bool flag_3_q_v_;
				for ( int i=0; i < processors_num_; i++ )
				{
					cout << array_of_values_[i] << endl;
				}// close for
				// pass through all values to check if first and second proposition hold
				for ( int i=0; i < processors_num_; i++ )
                                {
					if ( array_of_values_[i] % am_ == 9 )// check if there is a insert value of any processor that value_processor % AM = 9
					{
						propos1_ = true;
					}// close if
					if ( array_of_values_[i] % 2 == 1 )// check if there is a odd insert value
					{
						propos2_ = false;
					}// close if
					// if you find that there is a insert value for which first proposition holds and another( or the same ) insert value for which second
					// proposition doesn't, terminate loop
					if ( propos1_ == true && propos2_ == false )
					{
						break;
					}// close if
				}// close for
				// to check the third proposition for each even insert value i_q examine if there is a different insert value i_v so that i_q + i_v > 10
				for( int i = 0; i < processors_num_; i++ )
				{
					if ( array_of_values_[i] % 2 == 0)
					{
						flag_3_q_v_ = false; // at start flag is false for each even insert number that will be examined
						for( int j = 0; j < processors_num_; j++ )
						{
							if ( (i != j) && (array_of_values_[i] + array_of_values_[j] > 10) )
							{
								flag_3_q_v_ = true;
								break;//as you find i_v so that i_q + i_v > 10 and i_q is even terminate the examination for that i_q
							}// close if
						}// close inner for
						//if flag is false after examination then there is no i_v : i_q + i_v > 10 and i_q even number,
						//so third proposition doesn't hold => terminate the external for
						if( flag_3_q_v_ == false )
						{
							propos3_ = false;
						}// close inner if
					} //close if
				}// close for
				// after examination processor with id = 0 accounces the results
				cout <<"RESULT 1: My id = "<< id() << "(root)"<< ", proposition 1 << Exists q so that i_q % AM = 9 >> is "<< propos1_<< endl;
				cout <<"RESULT 2: My id = "<< id() << "(root)"<< ",proposition 2 << It doesn't exist q so that i_q % 2 =1 >> is "<< propos2_<< endl;
				cout <<"RESULT 3: My id = "<< id() << "(root)"<< ", proposition 3 << For each even i_q, exists i_v so that i_q + i_v > 10 >> is"<< propos3_<< endl;
			}// close inner if
			*/
			//cout <<"SUM: My id =  "<< id()<<" (root) in "<< rand_int_ <<" addition, sum = "<< sum_ << endl;
		}// close inner else
	}//close else
   }
}
#endif
