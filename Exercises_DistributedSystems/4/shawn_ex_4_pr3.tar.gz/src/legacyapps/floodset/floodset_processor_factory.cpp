/************************************************************************
 ** This file is part of the network simulator Shawn.                  **
 ** Copyright (C) 2004-2007 by the SwarmNet (www.swarmnet.de) project  **
 ** Shawn is free software; you can redistribute it and/or modify it   **
 ** under the terms of the BSD License. Refer to the shawn-licence.txt **
 ** file in the root of the Shawn source tree for further details.     **
 ************************************************************************/
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODSET

#include "legacyapps/floodset/floodset_processor_factory.h"
#include "legacyapps/floodset/floodset_processor.h"
#include "sys/processors/processor_keeper.h"
#include "sys/simulation/simulation_controller.h"
#include <iostream>

using namespace std;
using namespace shawn;

namespace floodset
{

   // ----------------------------------------------------------------------
   void
   floodsetProcessorFactory::
   register_factory( SimulationController& sc )
   throw()
   {
      sc.processor_keeper_w().add( new floodsetProcessorFactory );
   }
   // ----------------------------------------------------------------------
   floodsetProcessorFactory::
   floodsetProcessorFactory()
   {
      //cout << "HelloworldProcessorFactory ctor" << &auto_reg_ << endl;
   }
   // ----------------------------------------------------------------------
   floodsetProcessorFactory::
   ~floodsetProcessorFactory()
   {
      //cout << "HelloworldProcessorFactory dtor" << endl;
   }
   // ----------------------------------------------------------------------
   std::string
   floodsetProcessorFactory::
   name( void )
   const throw()
   {
      return "floodset";
   }
   // ----------------------------------------------------------------------
   std::string
   floodsetProcessorFactory::
   description( void )
   const throw()
   {
      return "Shawn floodset Processor";
   }
   // ----------------------------------------------------------------------
   shawn::Processor*
   floodsetProcessorFactory::
   create( void )
   throw()
   {
      return new FloodSet;
   }
}

#endif
