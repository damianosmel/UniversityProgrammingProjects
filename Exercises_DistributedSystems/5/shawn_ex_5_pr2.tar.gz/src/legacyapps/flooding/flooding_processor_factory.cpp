/************************************************************************
 ** This file is part of the network simulator Shawn.                  **
 ** Copyright (C) 2004-2007 by the SwarmNet (www.swarmnet.de) project  **
 ** Shawn is free software; you can redistribute it and/or modify it   **
 ** under the terms of the BSD License. Refer to the shawn-licence.txt **
 ** file in the root of the Shawn source tree for further details.     **
 ************************************************************************/
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODING

#include "legacyapps/flooding/flooding_processor_factory.h"
#include "legacyapps/flooding/flooding_processor.h"
#include "sys/processors/processor_keeper.h"
#include "sys/simulation/simulation_controller.h"
#include <iostream>

using namespace std;
using namespace shawn;

namespace flooding
{

   // ----------------------------------------------------------------------
   void
   FloodingProcessorFactory::
   register_factory( SimulationController& sc )
   throw()
   {
      sc.processor_keeper_w().add( new FloodingProcessorFactory );
   }
   // ----------------------------------------------------------------------
   FloodingProcessorFactory::
   FloodingProcessorFactory()
   {
      //cout << "HelloworldProcessorFactory ctor" << &auto_reg_ << endl;
   }
   // ----------------------------------------------------------------------
   FloodingProcessorFactory::
   ~FloodingProcessorFactory()
   {
      //cout << "HelloworldProcessorFactory dtor" << endl;
   }
   // ----------------------------------------------------------------------
   std::string
   FloodingProcessorFactory::
   name( void )
   const throw()
   {
      return "flooding";
   }
   // ----------------------------------------------------------------------
   std::string
   FloodingProcessorFactory::
   description( void )
   const throw()
   {
      return "Shawn flooding processor";
   }
   // ----------------------------------------------------------------------
   shawn::Processor*
   FloodingProcessorFactory::
   create( void )
   throw()
   {
      return new FloodingProcessor;
   }
}

#endif
