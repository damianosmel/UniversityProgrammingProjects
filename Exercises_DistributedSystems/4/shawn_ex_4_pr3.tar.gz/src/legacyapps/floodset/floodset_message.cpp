/************************************************************************
 ** This file is part of the network simulator Shawn.                  **
 ** Copyright (C) 2004-2007 by the SwarmNet (www.swarmnet.de) project  **
 ** Shawn is free software; you can redistribute it and/or modify it   **
 ** under the terms of the BSD License. Refer to the shawn-licence.txt **
 ** file in the root of the Shawn source tree for further details.     **
 ************************************************************************/
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODSET

#include "legacyapps/floodset/floodset_message.h"

namespace floodset
{

	// ----------------------------------------------------------------------
   floodsetMessage::
   floodsetMessage(int *values,int size)
    {
       setSize(size*4);
       values_ = new int[size];
       for(int i=0;i<size;i++)
           values_[i] = values[i];
    }
	// ----------------------------------------------------------------------
   floodsetMessage::
	~floodsetMessage()
	{
            delete[] values_;
        }

}
#endif
