#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODING

#include "legacyapps/flooding/flooding_message.h"

namespace flooding
{

	// ----------------------------------------------------------------------
   //FloodingMessage::
   //FloodingMessage(int hops,int parent, int id)
	FloodingMessage::
   	FloodingMessage(int hops,int parent, int id)
	{
		hops_ = hops;
		parent_ = parent;
		id_ = id;
	}
	// ----------------------------------------------------------------------
   FloodingMessage::
	~FloodingMessage()
	{}
   // ----------------------------------------------------------------------

}
#endif
