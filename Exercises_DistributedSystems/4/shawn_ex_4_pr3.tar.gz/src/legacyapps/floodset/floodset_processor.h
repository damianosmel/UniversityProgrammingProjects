/************************************************************************
 ** This file is part of the network simulator Shawn.                  **
 ** Copyright (C) 2004-2007 by the SwarmNet (www.swarmnet.de) project  **
 ** Shawn is free software; you can redistribute it and/or modify it   **
 ** under the terms of the BSD License. Refer to the shawn-licence.txt **
 ** file in the root of the Shawn source tree for further details.     **
 ************************************************************************/
#ifndef __SHAWN_LEGACYAPPS_FLOODSET_PROCESSOR_H
#define __SHAWN_LEGACYAPPS_FLOODSET_PROCESSOR_H
#include "_legacyapps_enable_cmake.h"
#ifdef ENABLE_FLOODSET

#include "sys/processor.h"
#include "sys/event_scheduler.h"
#include "legacyapps/floodset/floodset_message.h"
#include <string.h>

namespace floodset
{

   /**
    */
   class FloodSet
       : public shawn::Processor
   {
   public:
      ///@name Constructor/Destructor
      ///@{
      FloodSet();
      virtual ~FloodSet();
      ///@}

      ///@name Inherited from Processor
      ///@{
      /**
       */
      virtual void boot( void ) throw();
      /**
       */
      virtual bool process_message( const shawn::ConstMessageHandle& ) throw();
      /**
       */
      virtual void work( void ) throw();
      ///@}

      virtual void special_boot( void ) throw();

      //void handle_floodset_message( const floodsetMessage& floodsetmsg) throw();

      //void handle_flooding_message( const FloodingMessage& ) throw();

   private:
      ///@name Message Handling
      ///@{
      /**
       */
      void handle_flooding_message_node( const floodsetMessage& flooding );
      /**
       */
	//declare variables for input value, AM, number of processors, an array of stored values, count of unknown values into the array
	//maximum frequency of votes, value of maximum frequent vote, a flag to show tie of votes, variable to store processor's decision, the round of decision
	//the value of fail propability and the hyper bound of decision criterion
	shawn::IntegerTag *input_tag_;
  	int input_value_;
	int am_;
	int processors_num_;
	int *arrayOfValues_;
	//int *temp_array_;
	int count_unknown_;
	int max_freq_vote_;
	int max_freq_;
	int tie_flag_;
	int decision_;
	int decision_at_round_;
	float fail_prop_;
	float hyper_bound_;
   };

}

#endif
#endif
